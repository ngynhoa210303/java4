package com.example.BTVN_Buoi5.service;

public interface LoginService {
    boolean checkLogin(String usr, String psw);
}
